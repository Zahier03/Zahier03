/**
 * Visual Script Builder Server-Side Code
 * This Google Apps Script file handles the server-side operations for the Visual Script Builder application
 * including scheduled events, email sending, data processing, and dynamic UI updates.
 */

// Global variables for configuration
const CONFIG = {
  emailSettings: {
    senderName: "Visual Script Automations",
    replyTo: Session.getActiveUser().getEmail()
  },
  dateFormat: "yyyy-MM-dd",
  timeFormat: "HH:mm:ss",
  timeZone: Session.getScriptTimeZone()
};

/**
 * Shows the app in a custom sidebar in Google Sheets
 */
function showSidebar() {
  const ui = SpreadsheetApp.getUi();
  const html = HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Visual Script Builder')
    .setWidth(450);
  ui.showSidebar(html);
}

/**
 * Creates a standalone web app version
 */
function doGet(e) {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Visual Script Builder')
    .setSandboxMode(HtmlService.SandboxMode.IFRAME);
}

/**
 * Creates a custom menu when the spreadsheet opens
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  ui.createMenu('Visual Script')
    .addItem('Open Visual Script Builder', 'showSidebar')
    .addSeparator()
    .addItem('Run Scheduled Tasks', 'runScheduledTasks')
    .addItem('Settings', 'showSettings')
    .addToUi();
}

/**
 * Runs scheduled tasks that are due
 * This can be triggered by time-based triggers or manually
 */
function runScheduledTasks() {
  // Get all scheduled tasks from storage
  const tasks = getScheduledTasks();
  const now = new Date();
  let tasksRun = 0;
  
  // Check each task to see if it's due
  tasks.forEach(task => {
    if (isTaskDue(task, now)) {
      // Execute the task based on its type
      executeTask(task);
      
      // Update last run time
      task.lastRun = now.toISOString();
      tasksRun++;
      
      // Update task in storage
      updateTask(task);
    }
  });
  
  // Log the results
  Logger.log(`Scheduled task run completed. ${tasksRun} tasks executed.`);
  return tasksRun;
}

/**
 * Determines if a task is due to run
 */
function isTaskDue(task, currentTime) {
  // Check if task is enabled
  if (!task.enabled) return false;
  
  // Get the scheduled time
  const scheduledTime = new Date(task.scheduledTime);
  
  // If it's a one-time task, check if it's past the scheduled time and hasn't run yet
  if (task.frequency === 'once') {
    return currentTime >= scheduledTime && !task.lastRun;
  }
  
  // For recurring tasks, check when it last ran
  if (task.lastRun) {
    const lastRun = new Date(task.lastRun);
    
    // Calculate next run time based on frequency
    let nextRun = new Date(lastRun);
    
    switch (task.frequency) {
      case 'hourly':
        nextRun.setHours(nextRun.getHours() + 1);
        break;
      case 'daily':
        nextRun.setDate(nextRun.getDate() + 1);
        break;
      case 'weekly':
        nextRun.setDate(nextRun.getDate() + 7);
        break;
      case 'monthly':
        nextRun.setMonth(nextRun.getMonth() + 1);
        break;
      case 'custom':
        // Custom interval in minutes
        nextRun.setMinutes(nextRun.getMinutes() + (task.customInterval || 60));
        break;
    }
    
    // Check if it's time to run again
    return currentTime >= nextRun;
  }
  
  // If it has never run, check if it's past the scheduled start time
  return currentTime >= scheduledTime;
}

/**
 * Executes a task based on its type
 */
function executeTask(task) {
  try {
    switch (task.action) {
      case 'sendEmail':
        return sendScheduledEmail(task);
      case 'updateSheet':
        return updateSheetData(task);
      case 'createReport':
        return generateReport(task);
      case 'runScript':
        return executeCustomScript(task);
      case 'createCalendarEvent':
        return createCalendarEvent(task);
      default:
        Logger.log(`Unknown task action: ${task.action}`);
        return false;
    }
  } catch (error) {
    Logger.log(`Error executing task ${task.id}: ${error.message}`);
    // Store the error in the task's execution history
    if (!task.executionHistory) {
      task.executionHistory = [];
    }
    task.executionHistory.push({
      timestamp: new Date().toISOString(),
      status: 'error',
      message: error.message
    });
    return false;
  }
}

/**
 * Sends an email according to task configuration
 */
function sendScheduledEmail(task) {
  const { recipients, subject, body, attachments } = task.emailDetails;
  
  // Process any template variables in the subject and body
  const processedSubject = processTemplateVariables(subject);
  const processedBody = processTemplateVariables(body);
  
  // Prepare email options
  const options = {
    name: CONFIG.emailSettings.senderName,
    replyTo: CONFIG.emailSettings.replyTo,
    htmlBody: processedBody
  };
  
  // Handle attachments if any
  if (attachments && attachments.length > 0) {
    options.attachments = getAttachments(attachments);
  }
  
  // Send the email
  GmailApp.sendEmail(recipients.join(','), processedSubject, "", options);
  
  // Record successful execution
  if (!task.executionHistory) {
    task.executionHistory = [];
  }
  task.executionHistory.push({
    timestamp: new Date().toISOString(),
    status: 'success',
    message: `Email sent to ${recipients.join(', ')}`
  });
  
  return true;
}

/**
 * Updates data in a Google Sheet
 */
function updateSheetData(task) {
  const { spreadsheetId, sheetName, range, values, operation } = task.sheetDetails;
  
  // Get the spreadsheet and sheet
  let spreadsheet;
  if (spreadsheetId) {
    spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  } else {
    spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  }
  
  const sheet = sheetName ? spreadsheet.getSheetByName(sheetName) : spreadsheet.getActiveSheet();
  
  // Perform the operation
  switch (operation) {
    case 'update':
      // Update values in the specified range
      const updateRange = range ? sheet.getRange(range) : sheet.getDataRange();
      updateRange.setValues(values);
      break;
    case 'append':
      // Append a row to the sheet
      sheet.appendRow(values[0]);
      break;
    case 'clear':
      // Clear the specified range
      const clearRange = range ? sheet.getRange(range) : sheet.getDataRange();
      clearRange.clear();
      break;
    case 'formula':
      // Set a formula in a range
      const formulaRange = sheet.getRange(range);
      formulaRange.setFormula(values);
      break;
  }
  
  // Record successful execution
  if (!task.executionHistory) {
    task.executionHistory = [];
  }
  task.executionHistory.push({
    timestamp: new Date().toISOString(),
    status: 'success',
    message: `Sheet "${sheetName}" updated successfully`
  });
  
  return true;
}

/**
 * Generates a report (e.g., PDF, CSV)
 */
function generateReport(task) {
  const { reportType, destination, spreadsheetId, sheetName } = task.reportDetails;
  
  // Get the spreadsheet
  let spreadsheet;
  if (spreadsheetId) {
    spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  } else {
    spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  }
  
  // Generate the report based on type
  let reportBlob;
  
  switch (reportType) {
    case 'pdf':
      // Export the sheet as PDF
      const pdfBlob = spreadsheet.getAs('application/pdf');
      pdfBlob.setName(`${spreadsheet.getName()} - ${new Date().toISOString()}.pdf`);
      reportBlob = pdfBlob;
      break;
    case 'csv':
      // Export the sheet as CSV
      const sheet = sheetName ? spreadsheet.getSheetByName(sheetName) : spreadsheet.getActiveSheet();
      const csvData = convertRangeToCsvFile(sheet);
      const csvBlob = Utilities.newBlob(csvData, 'text/csv', `${sheet.getName()} - ${new Date().toISOString()}.csv`);
      reportBlob = csvBlob;
      break;
  }
  
  // Handle the destination
  switch (destination.type) {
    case 'email':
      GmailApp.sendEmail(
        destination.email,
        `${reportType.toUpperCase()} Report: ${spreadsheet.getName()}`,
        `Please find attached the ${reportType.toUpperCase()} report.`,
        {
          attachments: [reportBlob],
          name: CONFIG.emailSettings.senderName
        }
      );
      break;
    case 'drive':
      // Save to Google Drive
      const folder = destination.folderId 
        ? DriveApp.getFolderById(destination.folderId)
        : DriveApp.getRootFolder();
      folder.createFile(reportBlob);
      break;
  }
  
  // Record successful execution
  if (!task.executionHistory) {
    task.executionHistory = [];
  }
  task.executionHistory.push({
    timestamp: new Date().toISOString(),
    status: 'success',
    message: `${reportType.toUpperCase()} report generated and sent to ${destination.type}`
  });
  
  return true;
}

/**
 * Executes a custom script defined in the task
 */
function executeCustomScript(task) {
  const { functionName, parameters } = task.scriptDetails;
  
  // Check if the function exists
  if (typeof this[functionName] !== 'function') {
    throw new Error(`Function "${functionName}" not found`);
  }
  
  // Execute the function with parameters
  const result = this[functionName].apply(this, parameters || []);
  
  // Record successful execution
  if (!task.executionHistory) {
    task.executionHistory = [];
  }
  task.executionHistory.push({
    timestamp: new Date().toISOString(),
    status: 'success',
    message: `Custom script "${functionName}" executed successfully`,
    result: JSON.stringify(result)
  });
  
  return true;
}

/**
 * Creates a Google Calendar event
 */
function createCalendarEvent(task) {
  const { title, description, startTime, endTime, attendees, calendarId } = task.calendarDetails;
  
  // Get the calendar
  const calendar = calendarId 
    ? CalendarApp.getCalendarById(calendarId) 
    : CalendarApp.getDefaultCalendar();
  
  // Create the event
  const event = calendar.createEvent(
    title,
    new Date(startTime),
    new Date(endTime),
    {
      description: description,
      guests: attendees ? attendees.join(',') : ''
    }
  );
  
  // Record successful execution
  if (!task.executionHistory) {
    task.executionHistory = [];
  }
  task.executionHistory.push({
    timestamp: new Date().toISOString(),
    status: 'success',
    message: `Calendar event "${title}" created successfully`
  });
  
  return true;
}

/**
 * Gets all scheduled tasks from storage
 */
function getScheduledTasks() {
  // Get tasks from script properties
  const tasksJson = PropertiesService.getScriptProperties().getProperty('scheduledTasks');
  return tasksJson ? JSON.parse(tasksJson) : [];
}

/**
 * Saves all scheduled tasks to storage
 */
function saveScheduledTasks(tasks) {
  PropertiesService.getScriptProperties().setProperty('scheduledTasks', JSON.stringify(tasks));
  return tasks;
}

/**
 * Adds a new scheduled task
 */
function addScheduledTask(task) {
  // Generate a unique ID for the task
  task.id = Utilities.getUuid();
  
  // Set creation timestamp
  task.createdAt = new Date().toISOString();
  
  // Get existing tasks
  const tasks = getScheduledTasks();
  
  // Add the new task
  tasks.push(task);
  
  // Save tasks
  saveScheduledTasks(tasks);
  
  // Create time-based trigger if needed
  if (task.createTrigger) {
    createTaskTrigger(task);
  }
  
  return task;
}

/**
 * Updates an existing task
 */
function updateTask(task) {
  // Get existing tasks
  const tasks = getScheduledTasks();
  
  // Find the task to update
  const index = tasks.findIndex(t => t.id === task.id);
  
  if (index !== -1) {
    // Update the task
    tasks[index] = task;
    
    // Save tasks
    saveScheduledTasks(tasks);
    
    return task;
  }
  
  throw new Error(`Task with ID ${task.id} not found`);
}

/**
 * Deletes a task
 */
function deleteTask(taskId) {
  // Get existing tasks
  const tasks = getScheduledTasks();
  
  // Find the task to delete
  const index = tasks.findIndex(t => t.id === taskId);
  
  if (index !== -1) {
    // Remove the task
    const deletedTask = tasks.splice(index, 1)[0];
    
    // Save tasks
    saveScheduledTasks(tasks);
    
    // Delete any associated trigger
    deleteTaskTrigger(taskId);
    
    return deletedTask;
  }
  
  throw new Error(`Task with ID ${taskId} not found`);
}

/**
 * Creates a time-based trigger for a task
 */
function createTaskTrigger(task) {
  // Delete any existing trigger for this task
  deleteTaskTrigger(task.id);
  
  // Create a new trigger
  const trigger = ScriptApp.newTrigger('runTaskByTrigger')
    .timeBased();
  
  // Configure the trigger based on frequency
  switch (task.frequency) {
    case 'hourly':
      trigger.everyHours(1);
      break;
    case 'daily':
      trigger.everyDays(1);
      break;
    case 'weekly':
      trigger.everyWeeks(1);
      break;
    case 'monthly':
      // For monthly, we need to use a daily trigger and check the date in the handler
      trigger.everyDays(1);
      break;
    case 'custom':
      // For custom interval in minutes
      trigger.everyMinutes(task.customInterval || 60);
      break;
    case 'once':
      // For one-time trigger
      const scheduledTime = new Date(task.scheduledTime);
      trigger.at(scheduledTime);
      break;
  }
  
  // Create the trigger
  const triggerId = trigger.create().getUniqueId();
  
  // Store the trigger ID with the task
  task.triggerId = triggerId;
  updateTask(task);
  
  return triggerId;
}

/**
 * Deletes a time-based trigger for a task
 */
function deleteTaskTrigger(taskId) {
  // Get the task
  const tasks = getScheduledTasks();
  const task = tasks.find(t => t.id === taskId);
  
  if (task && task.triggerId) {
    // Find and delete the trigger
    const triggers = ScriptApp.getProjectTriggers();
    const trigger = triggers.find(t => t.getUniqueId() === task.triggerId);
    
    if (trigger) {
      ScriptApp.deleteTrigger(trigger);
    }
    
    // Remove the trigger ID from the task
    task.triggerId = null;
    updateTask(task);
  }
}

/**
 * Runs a specific task by trigger
 */
function runTaskByTrigger(e) {
  // Get the trigger ID
  const triggerId = e.triggerUid;
  
  // Find the task with this trigger ID
  const tasks = getScheduledTasks();
  const task = tasks.find(t => t.triggerId === triggerId);
  
  if (task) {
    // For monthly triggers, check if it's the right day of the month
    if (task.frequency === 'monthly') {
      const now = new Date();
      const scheduledDate = new Date(task.scheduledTime);
      
      // If today is not the same day of the month as the scheduled date, skip
      if (now.getDate() !== scheduledDate.getDate()) {
        return;
      }
    }
    
    // Execute the task
    executeTask(task);
    
    // Update last run time
    task.lastRun = new Date().toISOString();
    updateTask(task);
    
    // If it's a one-time task, disable it after running
    if (task.frequency === 'once') {
      task.enabled = false;
      updateTask(task);
    }
  }
}

/**
 * Process template variables in a string
 * Replaces {{variable}} with actual values
 */
function processTemplateVariables(text) {
  if (!text) return text;
  
  // Date and time variables
  const now = new Date();
  text = text.replace(/{{date}}/g, Utilities.formatDate(now, CONFIG.timeZone, CONFIG.dateFormat));
  text = text.replace(/{{time}}/g, Utilities.formatDate(now, CONFIG.timeZone, CONFIG.timeFormat));
  text = text.replace(/{{datetime}}/g, Utilities.formatDate(now, CONFIG.timeZone, `${CONFIG.dateFormat} ${CONFIG.timeFormat}`));
  
  // User variables
  text = text.replace(/{{user}}/g, Session.getActiveUser().getEmail());
  
  // Spreadsheet variables
  try {
    const activeSpreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    text = text.replace(/{{spreadsheet_name}}/g, activeSpreadsheet.getName());
    
    // Handle cell references like {{A1}} or {{Sheet1!B2}}
    text = text.replace(/{{([A-Za-z0-9]+!)?([A-Za-z]+[0-9]+)}}/g, (match, sheetName, cellRef) => {
      let sheet;
      if (sheetName) {
        // Remove the trailing !
        sheetName = sheetName.substring(0, sheetName.length - 1);
        sheet = activeSpreadsheet.getSheetByName(sheetName);
      } else {
        sheet = activeSpreadsheet.getActiveSheet();
      }
      
      if (sheet) {
        const cell = sheet.getRange(cellRef);
        return cell.getValue();
      }
      
      return match; // Keep the original if not found
    });
  } catch (e) {
    // Ignore spreadsheet variables if not in a spreadsheet context
  }
  
  return text;
}

/**
 * Converts a sheet range to a CSV file
 */
function convertRangeToCsvFile(sheet) {
  // Get the data range of the sheet
  const range = sheet.getDataRange();
  const data = range.getValues();
  
  // Convert the data to CSV
  let csv = '';
  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    // Format each cell and handle quotes in strings
    const formattedRow = row.map(cell => {
      if (typeof cell === 'string') {
        // Escape double quotes and wrap in quotes
        return `"${cell.replace(/"/g, '""')}"`;
      } else {
        return cell;
      }
    });
    csv += formattedRow.join(',') + '\n';
  }
  
  return csv;
}

/**
 * Gets file attachments from Google Drive
 */
function getAttachments(attachmentIds) {
  return attachmentIds.map(id => {
    try {
      return DriveApp.getFileById(id).getBlob();
    } catch (e) {
      Logger.log(`Error getting attachment with ID ${id}: ${e.message}`);
      return null;
    }
  }).filter(blob => blob !== null); // Remove any failed attachments
}

/**
 * Gets the HTML content for a UI component
 */
function getUIComponentHtml(componentType, properties) {
  // Create HTML for the requested component type
  switch (componentType) {
    case 'counter':
      return createCounterHtml(properties);
    case 'timer':
      return createTimerHtml(properties);
    case 'dateDisplay':
      return createDateDisplayHtml(properties);
    case 'tabs':
      return createTabsHtml(properties);
    case 'dataTable':
      return createDataTableHtml(properties);
    default:
      return `<div>Unknown component type: ${componentType}</div>`;
  }
}

/**
 * Creates HTML for a counter component
 */
function createCounterHtml(properties) {
  const { id, startValue, increment, label, format } = properties;
  
  // Format the counter display
  let displayFormat = '{{value}}';
  if (format) {
    displayFormat = format.replace('{{value}}', startValue || 0);
  }
  
  return `
<div id="${id}" class="counter-component">
  <div class="counter-label">${label || 'Counter'}</div>
  <div class="counter-value">${displayFormat}</div>
  <div class="counter-controls">
    <button class="counter-decrement">-</button>
    <button class="counter-increment">+</button>
  </div>
  <script>
    // Counter JavaScript
    (function() {
      const counter = document.getElementById('${id}');
      const valueEl = counter.querySelector('.counter-value');
      let value = ${startValue || 0};
      const increment = ${increment || 1};
      
      // Format function
      function formatValue(val) {
        let formatted = '${format || '{{value}}'}';
        return formatted.replace('{{value}}', val);
      }
      
      // Update display
      function updateDisplay() {
        valueEl.textContent = formatValue(value);
      }
      
      // Increment button
      counter.querySelector('.counter-increment').addEventListener('click', function() {
        value += increment;
        updateDisplay();
      });
      
      // Decrement button
      counter.querySelector('.counter-decrement').addEventListener('click', function() {
        value -= increment;
        updateDisplay();
      });
    })();
  </script>
</div>
  `;
}

/**
 * Creates HTML for a timer component
 */
function createTimerHtml(properties) {
  const { id, duration, autoStart, countDirection, onComplete } = properties;
  
  return `
<div id="${id}" class="timer-component">
  <div class="timer-display">
    <span class="timer-minutes">00</span>:<span class="timer-seconds">00</span>
  </div>
  <div class="timer-controls">
    <button class="timer-start">Start</button>
    <button class="timer-pause">Pause</button>
    <button class="timer-reset">Reset</button>
  </div>
  <script>
    // Timer JavaScript
    (function() {
      const timer = document.getElementById('${id}');
      const minutesEl = timer.querySelector('.timer-minutes');
      const secondsEl = timer.querySelector('.timer-seconds');
      const startBtn = timer.querySelector('.timer-start');
      const pauseBtn = timer.querySelector('.timer-pause');
      const resetBtn = timer.querySelector('.timer-reset');
      
      let duration = ${duration || 60}; // Default 60 seconds
      let timeLeft = ${countDirection === 'down' ? duration : 0};
      let timerId = null;
      
      // Format time
      function formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return {
          minutes: mins.toString().padStart(2, '0'),
          seconds: secs.toString().padStart(2, '0')
        };
      }
      
      // Update display
      function updateDisplay() {
        const formatted = formatTime(timeLeft);
        minutesEl.textContent = formatted.minutes;
        secondsEl.textContent = formatted.seconds;
      }
      
      // Timer tick
      function timerTick() {
        if ('${countDirection}' === 'down') {
          timeLeft--;
          if (timeLeft <= 0) {
            clearInterval(timerId);
            timeLeft = 0;
            ${onComplete ? onComplete : '// No completion action'};
          }
        } else {
          timeLeft++;
        }
        updateDisplay();
      }
      
      // Start timer
      function startTimer() {
        if (!timerId) {
          timerId = setInterval(timerTick, 1000);
          startBtn.disabled = true;
          pauseBtn.disabled = false;
        }
      }
      
      // Pause timer
      function pauseTimer() {
        if (timerId) {
          clearInterval(timerId);
          timerId = null;
          startBtn.disabled = false;
          pauseBtn.disabled = true;
        }
      }
      
      // Reset timer
      function resetTimer() {
        pauseTimer();
        timeLeft = ${countDirection === 'down' ? duration : 0};
        updateDisplay();
      }
      
      // Set up event listeners
      startBtn.addEventListener('click', startTimer);
      pauseBtn.addEventListener('click', pauseTimer);
      resetBtn.addEventListener('click', resetTimer);
      
      // Initial display update
      updateDisplay();
      
      // Auto-start if configured
      if (${autoStart ? 'true' : 'false'}) {
        startTimer();
      }
    })();
  </script>
</div>
  `;
}

/**
 * Creates HTML for a date display component
 */
function createDateDisplayHtml(properties) {
  const { id, format, updateInterval, highlightDates } = properties;
  
  return `
<div id="${id}" class="date-display-component">
  <div class="date-value"></div>
  <script>
    // Date display JavaScript
    (function() {
      const dateDisplay = document.getElementById('${id}');
      const valueEl = dateDisplay.querySelector('.date-value');
      
      // Format the date
      function formatDate(date) {
        const options = ${format ? JSON.stringify(format) : "{ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }"};
        return date.toLocaleDateString(undefined, options);
      }
      
      // Update the display
      function updateDisplay() {
        const now = new Date();
        valueEl.textContent = formatDate(now);
        
        // Check for highlighted dates
        const highlightDates = ${highlightDates ? JSON.stringify(highlightDates) : '[]'};
        const todayStr = now.toISOString().split('T')[0];
        
        // Reset any highlighting
        valueEl.classList.remove('date-highlighted');
        
        // Check if today is in the highlight list
        for (const date of highlightDates) {
          if (date === todayStr) {
            valueEl.classList.add('date-highlighted');
            break;
          }
        }
      }
      
      // Initial update
      updateDisplay();
      
      // Set up interval updates if configured
      if (${updateInterval ? 'true' : 'false'}) {
        setInterval(updateDisplay, ${updateInterval || 60000}); // Default to 1 minute
      }
    })();
  </script>
</div>
  `;
}

/**
 * Creates HTML for a tabs component
 */
function createTabsHtml(properties) {
  const { id, tabs } = properties;
  
  // Create HTML for tabs and tab content
  const tabsHtml = tabs.map((tab, index) => 
    `<div class="tab-item${index === 0 ? ' active' : ''}" data-tab="${index}">${tab.label}</div>`
  ).join('');
  
  const tabContentHtml = tabs.map((tab, index) => 
    `<div class="tab-content${index === 0 ? ' active' : ''}" data-tab-content="${index}">${tab.content}</div>`
  ).join('');
  
  return `
<div id="${id}" class="tabs-component">
  <div class="tabs-header">
    ${tabsHtml}
  </div>
  <div class="tabs-content">
    ${tabContentHtml}
  </div>
  <script>
    // Tabs JavaScript
    (function() {
      const tabsContainer = document.getElementById('${id}');
      const tabItems = tabsContainer.querySelectorAll('.tab-item');
      const tabContents = tabsContainer.querySelectorAll('.tab-content');
      
      // Show a tab
      function showTab(tabIndex) {
        // Hide all tabs
        tabItems.forEach(item => item.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Show the selected tab
        tabItems[tabIndex].classList.add('active');
        tabContents[tabIndex].classList.add('active');
      }
      
      // Set up click handlers for tabs
      tabItems.forEach(tab => {
        tab.addEventListener('click', function() {
          const tabIndex = parseInt(this.getAttribute('data-tab'));
          showTab(tabIndex);
        });
      });
    })();
  </script>
</div>
  `;
}

/**
 * Creates HTML for a data table component
 */
function createDataTableHtml(properties) {
  const { id, headers, data, sortable, filterable, pageable, pageSize } = properties;
  
  // Create the table header
  const headerHtml = headers.map(header => 
    `<th>${header}${sortable ? ' <span class="sort-indicator">⇅</span>' : ''}</th>`
  ).join('');
  
  // Create the table rows
  let rowsHtml = '';
  if (data && data.length) {
    rowsHtml = data.map(row => {
      const cells = row.map(cell => `<td>${cell}</td>`).join('');
      return `<tr>${cells}</tr>`;
    }).join('');
  }
  
  return `
<div id="${id}" class="data-table-component">
  ${filterable ? `
  <div class="table-filter">
    <input type="text" placeholder="Filter..." class="filter-input">
  </div>
  ` : ''}
  
  <table class="data-table">
    <thead>
      <tr>${headerHtml}</tr>
    </thead>
    <tbody>
      ${rowsHtml}
    </tbody>
  </table>
  
  ${pageable ? `
  <div class="table-pagination">
    <button class="page-prev">Previous</button>
    <span class="page-info">Page <span class="current-page">1</span> of <span class="total-pages">1</span></span>
    <button class="page-next">Next</button>
  </div>
  ` : ''}
  
  <script>
    // Data table JavaScript
    (function() {
      const tableContainer = document.getElementById('${id}');
      const table = tableContainer.querySelector('.data-table');
      const tbody = table.querySelector('tbody');
      const rows = Array.from(tbody.querySelectorAll('tr'));
      
      // Store the original data
      const originalRows = [...rows];
      let filteredRows = [...rows];
      
      ${filterable ? `
      // Set up filtering
      const filterInput = tableContainer.querySelector('.filter-input');
      filterInput.addEventListener('input', function() {
        const filterValue = this.value.toLowerCase();
        
        // Filter the rows
        filteredRows = originalRows.filter(row => {
          const text = row.textContent.toLowerCase();
          return text.includes(filterValue);
        });
        
        // Update the display
        updateDisplay();
      });
      ` : ''}
      
      ${sortable ? `
      // Set up sorting
      const headers = table.querySelectorAll('th');
      headers.forEach((header, index) => {
        header.addEventListener('click', function() {
          // Get the current sort direction
          const sortAsc = this.classList.contains('sort-asc');
          
          // Remove sort classes from all headers
          headers.forEach(h => {
            h.classList.remove('sort-asc', 'sort-desc');
          });
          
          // Set the new sort direction
          this.classList.add(sortAsc ? 'sort-desc' : 'sort-asc');
          
          // Sort the rows
          filteredRows.sort((a, b) => {
            const aValue = a.cells[index].textContent;
            const bValue = b.cells[index].textContent;
            
            // Try to sort as numbers if possible
            const aNum = parseFloat(aValue);
            const bNum = parseFloat(bValue);
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
              return sortAsc ? bNum - aNum : aNum - bNum;
            }
            
            // Sort as strings
            return sortAsc ? 
              bValue.localeCompare(aValue) : 
              aValue.localeCompare(bValue);
          });
          
          // Update the display
          updateDisplay();
        });
      });
      ` : ''}
      
      ${pageable ? `
      // Set up pagination
      const pageSize = ${pageSize || 10};
      let currentPage = 1;
      const prevButton = tableContainer.querySelector('.page-prev');
      const nextButton = tableContainer.querySelector('.page-next');
      const currentPageEl = tableContainer.querySelector('.current-page');
      const totalPagesEl = tableContainer.querySelector('.total-pages');
      
      prevButton.addEventListener('click', function() {
        if (currentPage > 1) {
          currentPage--;
          updateDisplay();
        }
      });
      
      nextButton.addEventListener('click', function() {
        const totalPages = Math.ceil(filteredRows.length / pageSize);
        if (currentPage < totalPages) {
          currentPage++;
          updateDisplay();
        }
      });
      ` : ''}
      
      // Function to update the display
      function updateDisplay() {
        ${pageable ? `
        // Calculate pagination
        const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
        currentPage = Math.min(currentPage, totalPages);
        
        // Update pagination display
        currentPageEl.textContent = currentPage;
        totalPagesEl.textContent = totalPages;
        
        // Enable/disable pagination buttons
        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages;
        
        // Get the rows for the current page
        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = startIndex + pageSize;
        const visibleRows = filteredRows.slice(startIndex, endIndex);
        
        // Clear the table
        tbody.innerHTML = '';
        
        // Add the visible rows
        visibleRows.forEach(row => {
          tbody.appendChild(row);
        });
        ` : `
        // Clear the table
        tbody.innerHTML = '';
        
        // Add all filtered rows
        filteredRows.forEach(row => {
          tbody.appendChild(row);
        });
        `}
      }
      
      // Initial display update
      updateDisplay();
    })();
  </script>
</div>
  `;
}

/**
 * Creates a time-based trigger for the script
 */
function createTimeTrigger(functionName, frequency, options) {
  // Delete any existing triggers for this function
  deleteTimeTrigger(functionName);
  
  // Create a new trigger
  const trigger = ScriptApp.newTrigger(functionName)
    .timeBased();
  
  // Configure based on frequency
  switch (frequency) {
    case 'minute':
      trigger.everyMinutes(options.interval || 1);
      break;
    case 'hour':
      trigger.everyHours(options.interval || 1);
      break;
    case 'day':
      trigger.everyDays(options.interval || 1);
      break;
    case 'week':
      trigger.everyWeeks(options.interval || 1);
      break;
    case 'month':
      // For monthly, we use a daily trigger and check the date in the handler
      trigger.everyDays(1);
      break;
    case 'specific':
      // For a specific time
      trigger.at(new Date(options.time));
      break;
  }
  
  // Create the trigger
  return trigger.create().getUniqueId();
}

/**
 * Deletes a time-based trigger for the script
 */
function deleteTimeTrigger(functionName) {
  const triggers = ScriptApp.getProjectTriggers();
  
  triggers.forEach(trigger => {
    if (trigger.getHandlerFunction() === functionName) {
      ScriptApp.deleteTrigger(trigger);
    }
  });
}

/**
 * Gets the current user's settings
 */
function getUserSettings() {
  const userEmail = Session.getActiveUser().getEmail();
  const userProperties = PropertiesService.getUserProperties();
  
  // Get settings or create default
  const settingsJson = userProperties.getProperty('userSettings');
  let settings = settingsJson ? JSON.parse(settingsJson) : {
    theme: 'light',
    dateFormat: CONFIG.dateFormat,
    timeFormat: CONFIG.timeFormat,
    defaultEmailTemplate: '',
    notifications: true
  };
  
  return settings;
}

/**
 * Saves the user's settings
 */
function saveUserSettings(settings) {
  const userProperties = PropertiesService.getUserProperties();
  userProperties.setProperty('userSettings', JSON.stringify(settings));
  return settings;
}

/**
 * Shows the settings dialog
 */
function showSettings() {
  const html = HtmlService.createHtmlOutputFromFile('settings')
    .setWidth(450)
    .setHeight(500);
  
  SpreadsheetApp.getUi().showModalDialog(html, 'Visual Script Builder Settings');
}

/**
 * Gets data from a spreadsheet for display in the UI
 */
function getSpreadsheetData(sheetName, range) {
  const sheet = sheetName ? 
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName) : 
    SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  
  if (!sheet) {
    throw new Error(`Sheet "${sheetName}" not found`);
  }
  
  const dataRange = range ? sheet.getRange(range) : sheet.getDataRange();
  return dataRange.getValues();
}

/**
 * Gets a list of sheets in the active spreadsheet
 */
function getSheetsList() {
  const sheets = SpreadsheetApp.getActiveSpreadsheet().getSheets();
  return sheets.map(sheet => ({
    name: sheet.getName(),
    id: sheet.getSheetId()
  }));
}

/**
 * Executes a conditional action based on a date condition
 */
function executeConditionalDateAction(condition) {
  const { date, compareType, action } = condition;
  
  // Get the target date
  const targetDate = new Date(date);
  targetDate.setHours(0, 0, 0, 0); // Set to start of day
  
  // Get today's date
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Set to start of day
  
  // Check the condition
  let conditionMet = false;
  
  switch (compareType) {
    case 'equals':
      conditionMet = targetDate.getTime() === today.getTime();
      break;
    case 'before':
      conditionMet = today.getTime() < targetDate.getTime();
      break;
    case 'after':
      conditionMet = today.getTime() > targetDate.getTime();
      break;
    case 'withinDays':
      const diffTime = Math.abs(targetDate.getTime() - today.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      conditionMet = diffDays <= condition.days;
      break;
  }
  
  // Execute the action if the condition is met
  if (conditionMet) {
    switch (action.type) {
      case 'sendEmail':
        GmailApp.sendEmail(
          action.email.to,
          action.email.subject,
          action.email.body,
          {
            name: CONFIG.emailSettings.senderName,
            htmlBody: action.email.htmlBody
          }
        );
        break;
      case 'showNotification':
        return {
          show: true,
          message: action.notification.message,
          type: action.notification.type || 'info'
        };
        break;
      case 'runFunction':
        // Run a custom function
        if (typeof this[action.function.name] === 'function') {
          return this[action.function.name].apply(this, action.function.parameters || []);
        }
        break;
    }
  }
  
  return { show: false };
}

/**
 * Creates a custom HTML component
 */
function createCustomComponent(html, css, js) {
  // Generate a unique ID for the component
  const componentId = 'component-' + Utilities.getUuid();
  
  // Create the HTML with scoped styles and script
  return `
<div id="${componentId}" class="custom-component">
  <style>
    /* Scoped styles */
    #${componentId} {
      ${css}
    }
  </style>
  
  <div class="component-content">
    ${html}
  </div>
  
  <script>
    // Scoped JavaScript
    (function() {
      const component = document.getElementById('${componentId}');
      ${js}
    })();
  </script>
</div>
  `;
}

/**
 * Example custom function that can be called from the UI
 */
function getWeatherData(location) {
  // This is a mock function - in a real app, you would call a weather API
  const mockWeatherData = {
    location: location || 'New York',
    temperature: Math.round(10 + Math.random() * 20),
    condition: ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy'][Math.floor(Math.random() * 4)],
    humidity: Math.round(40 + Math.random() * 40),
    windSpeed: Math.round(5 + Math.random() * 15)
  };
  
  return mockWeatherData;
}

/**
 * Example of getting data for a chart
 */
function getChartData(type, options) {
  // This creates mock data for different chart types
  let data = [];
  
  switch (type) {
    case 'line':
      // Create a line chart dataset with 12 months
      data = Array.from({length: 12}, (_, i) => {
        return {
          month: new Date(2023, i).toLocaleString('default', { month: 'short' }),
          value: Math.round(20 + Math.random() * 80)
        };
      });
      break;
    case 'bar':
      // Create a bar chart dataset
      data = ['Category A', 'Category B', 'Category C', 'Category D'].map(cat => {
        return {
          category: cat,
          value: Math.round(10 + Math.random() * 90)
        };
      });
      break;
    case 'pie':
      // Create a pie chart dataset
      data = ['Segment 1', 'Segment 2', 'Segment 3', 'Segment 4', 'Segment 5'].map(seg => {
        return {
          name: seg,
          value: Math.round(10 + Math.random() * 40)
        };
      });
      break;
  }
  
  return data;
}
